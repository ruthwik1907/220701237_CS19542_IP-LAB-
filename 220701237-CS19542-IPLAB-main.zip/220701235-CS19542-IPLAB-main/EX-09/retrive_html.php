<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>RETRIVE YOUR EMPLOYEE DETAILS</H2>
    <form action="retrive.php">
        <input type="text" name="emp_id">
        <input type="submit">
    </form>
</body>
</html>