<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="insert.php" method="POST">
      EMPLOYEE ID:<input type="text" name="emp_id" ><br>
      EMPLOYEE NAME:<input type="text" name="emp_name" ><br>
      DESIGNATION :<input type="text" name="desig" ><br>
      DEPARTMENT:<input type="text" name="dept" ><br>
      DATE OF JOIN:<input type="date" name="doj"><br>
      SALARY(in rupees):<input type="text" name="salary"><br>
       <input type="submit" name="submit">
    </form>
</body>
</html>