<html>
<head>
    <title>LOGIN</title>
</head>
<body>
    <h2>HAPPY BANKING!!</h2>
    <form action="insert1_html.php">
        <input type="SUBMIT" >
    </form>
</body>
</html>