<html>
    <head>
        <title>TRANSACTION</title>
    </head>
    <body>
        <form action ="trphp.php" method="POST">
            ENTER YOUR ACCOUNT NUMBER:<input type="text" NAME="ano"><br>
            ENTER THE TYPE OF TRANSACTION:<br><INPUT TYPE="radio" name="tt" value="d">DEPOSIT
            <INPUT TYPE="RADIO" name="tt" value="w">WITHDRAWAL<br>
            ENTER TRANSACTION AMOUNT:<input type="text" name="tamt"> 
            <br><INPUT type="submit">
        </form>
    </body>
</html>