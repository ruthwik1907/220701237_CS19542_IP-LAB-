<html>
    <head>
        <title>SERVICES</title>
    </head>
    <body>
        <form action="checkbal.php" method="POST">
            ENTER YOUR ACCOUNT NUMBER:<input type="text" name="ano"><BR>
            <input type="submit" value="CHECK BALANCE">
        </form>
        <form action="transact.php">
            <input type="submit" value="TRANSACT">
        </form>
    </body>
</html>