<h2>THANKS FOR USING OUR SERVICE</h2>
<form action="index.php">
    <input type="submit" value="GO TO HOME PAGE">
</form>