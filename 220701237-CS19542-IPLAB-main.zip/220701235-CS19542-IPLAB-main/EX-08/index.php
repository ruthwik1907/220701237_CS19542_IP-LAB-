<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <centre>
      <h2>WELCOME TO MY BANK!!</h2>
       <FORM action="insert1_html.php">
        <button>NEW USER</button>
       </FORM>
       <FORM action="service.php">
        <button>OLD USER</button>
       </FORM>
    
    </centre>
</body>
</html>