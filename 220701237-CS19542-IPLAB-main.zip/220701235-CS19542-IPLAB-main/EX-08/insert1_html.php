<html>
<head>
    <title>CREATE ACCOUNT</title>
</head>    
<body>
    <form action="insert1.php" method="POST">
       ENTER YOUR NAME: <input type="text" name="cname"><br>
       CHOOSE THE ACCOUNT TYPE:
       <input type="radio" name="atype" value="s">SAVINGS<br>
       <input type="radio" name="atype" value="c">CURRENT<br>
       <input type="submit">
    </form>
</body>
</html>